

<section id="precios" class="jumbotron text-center">
 
        

        <div class="container">
          <div class="card-deck mb-3 text-center">

          <div class="price-table col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <div  class="box-plan">
              <div class="plan-title price-bg">
                <h3>Inicial</h3>
              </div>
              <div class="price"> 
              <h1 class="card-title pricing-card-title">$1,000 <small class="text-muted">/ año</small></h1>
             </div>
              <div class="descr">
                <p>Dominio.com</p>
                <hr>
                <p>Plantilla 1 seccion</p>
                <hr>
                <p>Certificado SSL</p>
                <hr>
                <p>Enlace a redes sociales</p>
                <hr>
                <p>Hosting</p>
              </div>
              <!-- <div class="plan-btn"> <a href="#" class="btn btn-default btn-block btn-lg">Sign Up</a> </div> -->
            </div>
          </div>

          <div class="price-table col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <div  class="box-plan">
              <div class="plan-title price-bg">
                <h3>Emprendedor</h3>
              </div>
              <div class="price"> 
              <h1 class="card-title pricing-card-title">$2,000 <small class="text-muted">/ año</small></h1>
             </div>
              <div class="descr">
                <p>Caracteristicas pagina web inicial</p>
                <hr>
                <p>Boton Whatsup, Messenger</p>
                <hr>
                <p>Correo Electronico @midominio.com</p>
                <hr>
                <p>Blog</p>
              </div>
              <!-- <div class="plan-btn"> <a href="#" class="btn btn-default btn-block btn-lg">Sign Up</a> </div> -->
            </div>
          </div>

          <div class="price-table col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <div  class="box-plan">
              <div class="plan-title price-bg">
                <h3>Profesional</h3>
              </div>
              <div class="price"> 
              <h1 class="card-title pricing-card-title">$2,000 <small class="text-muted">/ año</small></h1>
             </div>
              <div class="descr">
                <p>Caracteristicas Web Emprendedor</p>
                <hr>
                <p>Login</p>
                <hr>
                <p>5 Projects</p>
                <hr>
                <p>24/7 Email support</p>
              </div>
              <!-- <div class="plan-btn"> <a href="#" class="btn btn-default btn-block btn-lg">Sign Up</a> </div> -->
            </div>
          </div>
         </div>
        </div>




</section">

