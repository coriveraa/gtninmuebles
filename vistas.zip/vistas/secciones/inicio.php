<?php

    include "banner.php";
    include "cartas.php";
    // include "buscador.php";
    include "jumbotron_msn.php";
    // include "producto_estrella.php";
    // include "newsletter.php";
    //  include "precios.php";
    //  include "cover.php";
    //  include "contacto.php";
