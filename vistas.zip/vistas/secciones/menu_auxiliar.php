<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="#inicio">
    <!-- <img src="/docs/4.6/assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt=""> -->
    Nosotros
  </a>
  <a class="navbar-brand" href="#pventa">
    <!-- <img src="/docs/4.6/assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt=""> -->
    puntos de venta
  </a>
</nav>