

<div id="inicio">      
 <div class="card-group">

  <div class="card">
<!--    <img src="<?php echo $landingPage["dominio"];?>..." class="card-img-top" alt="...">-->
   
    <div class="card-body">
     <!-- <i class='fas fa-user-circle ' style='font-size:48px;color:red'></i> -->
      <h5 class="card-title text-primary text-center">Venta</h5>
      <p class="card-text text-info text-center">Vendemos tu propiedad y nos encargamos de todo el proceso</p>
     <!-- <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p> -->
    </div>
  </div>

  
  <div class="card">
<!--    <img src="<?php echo $landingPage["dominio"];?>..." class="card-img-top" alt="...">-->
    <div class="card-body">
     <!-- <i class='fas fa-chart-line' style='font-size:48px;color:red'></i> -->
      <h5 class="card-title text-primary text-center">Renta</h5>
      <p class="card-text text-info text-center">Encontramos la mejor opcion</p>
<!--      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>-->
    </div>
  </div>
  <div class="card">
<!--    <img src="<?php echo $landingPage["dominio"];?>..." class="card-img-top" alt="...">-->
    <div class="card-body">
     <!-- <i class='far fa-comments' style='font-size:48px;color:red'></i> -->
      <h5 class="card-title text-primary text-center">Analisis de mercado comparativo</h5>
      <p class="card-text text-info text-center">Conoce cuanto vale tu propiedad en el mercado</p>
<!--      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>-->
    </div>
  </div>
</div>