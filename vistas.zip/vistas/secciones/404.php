<div class"text-center">

    <h1>404<h1>
    <p>PAGINA NO ENCONTRADA</p>

   
</div>
