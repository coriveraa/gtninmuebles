<section id="producto_estrella" class="jumbotron text-center">
    <div class="container ">
      <h1 class="text-primary">Puntos de Venta </h1>
      <p class="lead text-muted">¿Necesitas un Punto de Venta para tu Negocio ?</p>
      <!-- <p class="lead text-muted">Adquiere tu punto de Venta y obten software GRATIS!!!</p> -->
 
      <p>
        <!-- <a href="#" class="btn btn-primary my-2">Main call to action</a> -->
        <!-- <a href="#" class="btn btn-secondary my-2">Secondary action</a> -->
      </p>
    </div>
    <div class="container">
      <img  class="bd-placeholder-img" width="100%" height="100%"  src="vistas/img/banners/punto_venta.png" alt="">
    </div>
 </section>

 <!-- <section class="jumbotron text-center">
  
 </section> -->

