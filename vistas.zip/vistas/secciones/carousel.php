<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active carruseluno" > 
         <!-- style ="backgound:url(<?php echo $categorias[0]["img_categoria"]?>)" -->
        <!-- <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" role="img" aria-label=" :  " preserveAspectRatio="xMidYMid slice" focusable="false"><title> </title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"> </text></svg> -->
        <!-- <img class="bd-placeholder-img" width="100%" height="100%" src="vistas/img/banneruno.jpg" alt="First slide"> -->

        <div class="container">
          <div class="carousel-caption text-right">
           <h1 class ="text-primary float-left">Soluciones en Informatica</h1>
            <!-- <p>Has que tus clientes te encuntren</p> -->
            <!-- <p><a class="btn btn-lg btn-primary" href="#">Sign up today</a></p> -->
          </div>
        </div>
      </div>
      <div class="carousel-item carruseldos">
        <!-- <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" role="img" aria-label=" :  " preserveAspectRatio="xMidYMid slice" focusable="false"><title> </title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"> </text></svg> -->
        <!-- <img class="bd-placeholder-img" width="100%" height="100%" src="vistas/img/bannerdos-removebg-preview.png" alt="First slide"> -->
        <div class="container">
          <div class="carousel-caption text-right">
            <h1 class="text-primary float-left">Paginas Web</h1>
            <!-- <p>Tu perfil digital en la red</p>  -->
            <!-- <p><a class="btn btn-lg btn-primary" href="#">Learn more</a></p> -->
          </div>
        </div>
      </div>
      <div class="carousel-item carruseltres">
        <!-- <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" role="img" aria-label=" :  " preserveAspectRatio="xMidYMid slice" focusable="false"><title> </title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"> </text></svg> -->
        <!-- <img class="bd-placeholder-img" width="100%" height="100%" src="vistas/img/bannertres.jpg" alt="First slide"> -->

        <div class="container ">
          <div class="carousel-caption text-right">
             <h1 class="text-primary float-left">Smart Home</h1>
            <!-- <p>Tu negocio en internet</p>  -->
            <!-- <p><a class="btn btn-lg btn-primary" href="#">Browse gallery</a></p> -->
          </div>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>

  

  </div>