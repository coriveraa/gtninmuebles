


<section id ='home' class="jumbotron text-left text-primary ">

    <div class="container home-content">


    <?php
    
    include "buscador.php";
    
    ?>
      <!-- <h1 >Buscar Propiedad</h1> -->
      <!-- <h2></h2> -->
      <!-- <p class="lead text-muted">Las mejores marcas en tecologia a tu alcance</p> -->
      <!-- <p>
        <a href="#" class="btn btn-primary my-2">Main call to action</a>
        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
      </p> -->
      <!-- <button type="button" class="btn btn-lg">Large button</button> -->

    </div>

</section>

