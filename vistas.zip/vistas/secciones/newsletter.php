  <!-- #newsletter-section -->
  <section id="newsletter-section">
    <div class="container">
      <div class="row clearfix">
        <!-- .newsletter-form -->
      <div id="message" class="text-left" ></div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus similique sapiente quis quas maxime velit illum ea, suscipit aut ipsam voluptates, quia, ducimus voluptate facere quod a architecto. Quo, fuga.</p>
      <!-- <form class="form-horizontal newsletter-form" id="signup" role="form">
        <div class="form-group">
          <div class="form-element col-xs-12 col-sm-3 col-md-3 col-lg-3">
            <div class="input-group col-xs-12 col-sm-12">
              <label>First Name</label>
              <input type="text" class="form-control" id="firstname" name="name" placeholder="">
            </div>
          </div>
          <div class="form-element col-xs-12 col-sm-3 col-md-3 col-lg-3">
            <div class="input-group col-xs-12 col-sm-12">
              <label>Last Name</label>
              <input type="text" class="form-control" id="lastname" name="name" placeholder="">
            </div>
          </div>
          <div class="form-element col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <div class="input-group col-xs-12 col-sm-12">
              <label>Your email</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="">
            </div>
          </div>
          <div class="form-element col-xs-12 col-sm-2 col-md-2 col-lg-2">
            <p class="subscription-button text-center">
              <button type="submit" id="SendButton" name="submit" class="btn btn-custom-1"><i class="fa fa-envelope"></i> <strong>Subscribe</strong></button>
            </p>
          </div>
        </div>
      </form> -->
      <!-- /.newsletter-form -->
      </div>
    </div>
  </section>
  <!-- /#newsletter-section --> 