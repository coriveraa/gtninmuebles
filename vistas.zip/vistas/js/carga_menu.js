function cargaMenu(varMenu){   
	
//    if (varMenu == 'inicio'){
//        alert('Carga: '+varMenu);
        $('#contenido').load(varMenu);   
//    };

    };