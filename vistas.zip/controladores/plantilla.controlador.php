<?php

Class ControladorPlantilla{


    public function ctrTraerPlantilla(){

        include "vistas/plantilla.php";

    }


}